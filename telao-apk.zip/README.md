# Telão

Interface de streaming (demonstração) empacotada como app Android com Capacitor.

## Gerar o APK no GitHub

1. Crie um repositório novo no GitHub e envie todos os arquivos desta pasta para a branch `main`.
2. Abra a aba **Actions** do repositório. O fluxo **Build APK** roda sozinho a cada envio, ou use **Run workflow**.
3. Quando terminar (cerca de 4 a 6 minutos), abra a execução e baixe `telao-apk` em **Artifacts**.
4. Descompacte e instale `app-debug.apk` no celular. Pode ser preciso permitir instalação de fontes desconhecidas.

O site fica em `www/index.html`. Para mudar algo, edite esse arquivo e envie de novo.
